CREATE DATABASE naz225
    WITH
    OWNER = postgres
    ENCODING = 'UTF8'
    LC_COLLATE = 'Russian_Russia.1251'
    LC_CTYPE = 'Russian_Russia.1251'
    LOCALE_PROVIDER = 'libc'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1
    IS_TEMPLATE = False;
	
CREATE SCHEMA IF NOT EXISTS data
    AUTHORIZATION postgres;

CREATE SEQUENCE IF NOT EXISTS data.sq_counters_id
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 100
    CACHE 1;
	
CREATE SEQUENCE IF NOT EXISTS data.sq_locations_id
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 100
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS data.sq_measurments_id
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 10000
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS data.sq_rates_id
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 100
    CACHE 1;

CREATE SEQUENCE IF NOT EXISTS data.sq_types_id
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 100
    CACHE 1;

CREATE TABLE IF NOT EXISTS data.counters
(
    id integer NOT NULL DEFAULT nextval('data.sq_counters_id'::regclass),
    location_id integer NOT NULL,
    type_id integer NOT NULL,
    rate_id integer NOT NULL,
    CONSTRAINT pk_counters_id PRIMARY KEY (id),
    CONSTRAINT fk_counters_locations FOREIGN KEY (location_id)
        REFERENCES data.locations (id) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE NO ACTION,
    CONSTRAINT fk_counters_rates FOREIGN KEY (rate_id)
        REFERENCES data.rates (id) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE NO ACTION,
    CONSTRAINT fk_counters_types FOREIGN KEY (type_id)
        REFERENCES data.types (id) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE NO ACTION
)

CREATE TABLE IF NOT EXISTS data.loc_profiles
(
    id integer NOT NULL DEFAULT nextval('sq_loc_prof_lc'::regclass),
    profile integer NOT NULL,
    name character varying(10) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT loc_profiles_pkey PRIMARY KEY (id)
)

CREATE TABLE IF NOT EXISTS data.locations
(
    id integer NOT NULL DEFAULT nextval('data.sq_locations_id'::regclass),
    city character varying(75) COLLATE pg_catalog."default" NOT NULL,
    street character varying(75) COLLATE pg_catalog."default" NOT NULL,
    house integer NOT NULL,
    flat integer NOT NULL,
    profile integer,
    CONSTRAINT pk_locations_id PRIMARY KEY (id),
    CONSTRAINT loc_pr_fork FOREIGN KEY (profile)
        REFERENCES data.loc_profiles (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

CREATE TABLE IF NOT EXISTS data.measurments
(
    id integer NOT NULL DEFAULT nextval('data.sq_measurments_id'::regclass),
    counter_id integer NOT NULL,
    mark timestamp without time zone NOT NULL,
    value double precision NOT NULL,
    photo character varying(25) COLLATE pg_catalog."default",
    CONSTRAINT pk_measurments_id PRIMARY KEY (id),
    CONSTRAINT fk_measurmentes_counters FOREIGN KEY (counter_id)
        REFERENCES data.counters (id) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE NO ACTION,
    CONSTRAINT chk_measurments_mark_after_date CHECK (mark > '2021-01-01 00:00:00'::timestamp without time zone),
    CONSTRAINT chk_measurments_mark_not_in_future CHECK (mark < now()),
    CONSTRAINT chk_measurments_value_greater_than_last CHECK (value >= data.fn_last_counter_value(counter_id)),
    CONSTRAINT chk_measurments_value_positive_or_zero CHECK (value >= 0.0::double precision)
)

CREATE TABLE IF NOT EXISTS data.rates
(
    id integer NOT NULL DEFAULT nextval('data.sq_rates_id'::regclass),
    since timestamp without time zone NOT NULL,
    cost double precision NOT NULL,
    CONSTRAINT pk_rates_id PRIMARY KEY (id),
    CONSTRAINT chk_rates_cost_positive_or_zero CHECK (cost >= 0.0::double precision),
    CONSTRAINT chk_rates_since_after_date CHECK (since > '2021-01-01 00:00:00'::timestamp without time zone)
)

CREATE TABLE IF NOT EXISTS data.types
(
    id integer NOT NULL DEFAULT nextval('data.sq_types_id'::regclass),
    name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    unit character varying(5) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT pk_types_id PRIMARY KEY (id),
    CONSTRAINT chk_types_name CHECK (length(name::text) >= 2),
    CONSTRAINT chk_types_unit CHECK (length(unit::text) >= 2)
)

drop view if exists data.count1_view;
drop view if exists data.count2_view;
drop view if exists data.count3_view;
drop view if exists data.count4_view;
drop view if exists data.count5_view;
drop view if exists data.count6_view;
drop view if exists data.count7_view;

CREATE OR REPLACE VIEW data.count1_view AS
    SELECT counters.id AS counter_id, 
           types.name AS type_name, 
           rates.cost AS rate_cost, 
           locations.id AS location_id
    FROM data.counters
    INNER JOIN data.locations ON counters.location_id = locations.id
    INNER JOIN data.types ON counters.type_id = types.id
    INNER JOIN data.rates ON counters.rate_id = rates.id
    WHERE data.counters.id = 1;

CREATE OR REPLACE VIEW data.count2_view AS
    SELECT counters.id AS counter_id, 
           types.name AS type_name, 
           rates.cost AS rate_cost, 
           locations.id AS location_id
    FROM data.counters
    INNER JOIN data.locations ON counters.location_id = locations.id
    INNER JOIN data.types ON counters.type_id = types.id
    INNER JOIN data.rates ON counters.rate_id = rates.id
    WHERE data.counters.id = 2;

CREATE OR REPLACE VIEW data.count3_view AS
    SELECT counters.id AS counter_id, 
           types.name AS type_name, 
           rates.cost AS rate_cost, 
           locations.id AS location_id
    FROM data.counters
    INNER JOIN data.locations ON counters.location_id = locations.id
    INNER JOIN data.types ON counters.type_id = types.id
    INNER JOIN data.rates ON counters.rate_id = rates.id
    WHERE data.counters.id = 3;

CREATE OR REPLACE VIEW data.count4_view AS
    SELECT counters.id AS counter_id, 
           types.name AS type_name, 
           rates.cost AS rate_cost, 
           locations.id AS location_id
    FROM data.counters
    INNER JOIN data.locations ON counters.location_id = locations.id
    INNER JOIN data.types ON counters.type_id = types.id
    INNER JOIN data.rates ON counters.rate_id = rates.id
    WHERE data.counters.id = 4;

CREATE OR REPLACE VIEW data.count5_view AS
    SELECT counters.id AS counter_id, 
           types.name AS type_name, 
           rates.cost AS rate_cost, 
           locations.id AS location_id
    FROM data.counters
    INNER JOIN data.locations ON counters.location_id = locations.id
    INNER JOIN data.types ON counters.type_id = types.id
    INNER JOIN data.rates ON counters.rate_id = rates.id
    WHERE data.counters.id = 5;

CREATE OR REPLACE VIEW data.count6_view AS
    SELECT counters.id AS counter_id, 
           types.name AS type_name, 
           rates.cost AS rate_cost, 
           locations.id AS location_id
    FROM data.counters
    INNER JOIN data.locations ON counters.location_id = locations.id
    INNER JOIN data.types ON counters.type_id = types.id
    INNER JOIN data.rates ON counters.rate_id = rates.id
    WHERE data.counters.id = 6;

CREATE OR REPLACE VIEW data.count7_view AS
    SELECT counters.id AS counter_id, 
           types.name AS type_name, 
           rates.cost AS rate_cost, 
           locations.id AS location_id
    FROM data.counters
    INNER JOIN data.locations ON counters.location_id = locations.id
    INNER JOIN data.types ON counters.type_id = types.id
    INNER JOIN data.rates ON counters.rate_id = rates.id
    WHERE data.counters.id = 7;