-- table counters
CREATE TEMP TABLE temp_counters (id int, location_id int, type_id int, rate_id int);
COPY temp_counters(id,location_id,type_id,rate_id) FROM 'C:\course\counters.csv' WITH CSV;
INSERT INTO data.counters(id,location_id,type_id,rate_id) SELECT id,location_id,type_id,rate_id FROM temp_counters;
drop table temp_counters;

-- table loc_profiles
CREATE TEMP TABLE temp_loc_p (id int, profile int, name text);
cOPY temp_loc_p(id,profile,name) FROM 'C:\course\loc_profiles.csv' WITH CSV;
INSERT INTO data.loc_profiles(id,profile,name) SELECT id,profile,name FROM temp_loc_p;
drop table temp_loc_p;

-- table locations
CREATE TEMP TABLE temp_loc (id int,city text,street text,house int,flat int,profile int);
cOPY temp_loc(id,city,street,house,flat,profile) FROM 'C:\course\locations.csv' WITH CSV;
INSERT INTO data.locations(id,city,street,house,flat,profile) SELECT id,city,street,house,flat,profile FROM temp_loc;
drop table temp_loc;

-- table measurments
CREATE TEMP TABLE temp_mes (id int,value double precision, counter_id int, mark timestamp without time zone,photo text);
cOPY temp_mes(id,counter_id,mark,value,photo) FROM 'C:\course\measurments.csv' WITH CSV NULL 'NULL';
INSERT INTO data.measurments(id,counter_id,mark,value,photo) SELECT id,counter_id,mark,value,photo FROM temp_mes;
drop table temp_mes;

-- table rates
CREATE TEMP TABLE temp_rates (id int,since timestamp without time zone,cost double precision);
cOPY temp_rates(id,since,cost) FROM 'C:\course\rates.csv' WITH CSV;
INSERT INTO data.rates(id,since,cost) SELECT id,since,cost FROM temp_rates;
drop table temp_rates;

-- table types
CREATE TEMP TABLE temp_types (id int,name text,unit text);
cOPY temp_types(id,name,unit) FROM 'C:\course\types.csv' WITH CSV;
INSERT INTO data.types(id,name,unit) SELECT id,name,unit FROM temp_types;
drop table temp_types;

-- mat views for measurments

CREATE MATERIALIZED VIEW IF NOT EXISTS data.measur_count1
TABLESPACE pg_default
AS
 SELECT id,
    counter_id,
    mark,
    value,
    photo
   FROM data.measurments WHERE counter_id = 1
WITH DATA;
	
CREATE MATERIALIZED VIEW IF NOT EXISTS data.measur_count2
TABLESPACE pg_default
AS
 SELECT id,
    counter_id,
    mark,
    value,
    photo
   FROM data.measurments WHERE counter_id = 2
WITH DATA;
	
CREATE MATERIALIZED VIEW IF NOT EXISTS data.measur_count3
TABLESPACE pg_default
AS
 SELECT id,
    counter_id,
    mark,
    value,
    photo
   FROM data.measurments WHERE counter_id = 3
WITH DATA;
	
CREATE MATERIALIZED VIEW IF NOT EXISTS data.measur_count4
TABLESPACE pg_default
AS
 SELECT id,
    counter_id,
    mark,
    value,
    photo
   FROM data.measurments WHERE counter_id = 4
WITH DATA;
	
CREATE MATERIALIZED VIEW IF NOT EXISTS data.measur_count5
TABLESPACE pg_default
AS
 SELECT id,
    counter_id,
    mark,
    value,
    photo
   FROM data.measurments WHERE counter_id = 5
WITH DATA;
	
CREATE MATERIALIZED VIEW IF NOT EXISTS data.measur_count6
TABLESPACE pg_default
AS
 SELECT id,
    counter_id,
    mark,
    value,
    photo
   FROM data.measurments WHERE counter_id = 6
WITH DATA;
	
CREATE MATERIALIZED VIEW IF NOT EXISTS data.measur_count7
TABLESPACE pg_default
AS
 SELECT id,
    counter_id,
    mark,
    value,
    photo
   FROM data.measurments WHERE counter_id = 7
WITH DATA;